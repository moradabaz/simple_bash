package es.um.poa.ontologies;

import java.io.IOException;
import java.io.Serializable;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SimTimeOntology {
	
	public static String RUNNING = "RUNNING";
	public static String END = "END";
	
	private String simState;
	private int day;
	private int time;
	
	public SimTimeOntology(int day, int time) {
		this.simState = RUNNING;
		this.day = day;
		this.time = time;
	}
	
	public String getSimState() {
		return simState;
	}
	public void setSimState(String sim_state) {
		this.simState = sim_state;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	
	public String toString() {
		return "SimTimeOntology(day="+day+",time="+time+",simState="+simState+")";
	}
}
