package es.um.poa;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import es.um.poa.ontologies.OntologyFactory;
import es.um.poa.ontologies.SimTimeOntology;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.util.Logger;
import jade.proto.SubscriptionResponder;
import jade.proto.SubscriptionResponder.Subscription;
import jade.proto.SubscriptionResponder.SubscriptionManager;

/**
 * Agente que controla la tiempo de la simulación
 * 
 * @author pablo
 *
 */
public class ClockAgent extends Agent {
	private Logger logger;
	
	public void setup() {
		this.logger = Logger.getMyLogger(getClass().getCanonicalName());
		
		Object[] args = getArguments();
		if (args != null && args.length == 3) {
			int unitTimeMillis = Integer.parseInt((String) args[0]);
			int numUnitDay = Integer.parseInt((String) args[1]);
			int numSimDays = Integer.parseInt((String) args[2]);
			this.logger.info(getName()+": setup ("+
					"unitTimeMillis="+unitTimeMillis+", "+
					"numUnitDay="+numUnitDay+", "+
					"numSimDays="+numSimDays);
			
			ClockTickerBehaviour clockBehaviour = new ClockTickerBehaviour(this, unitTimeMillis, numUnitDay, numSimDays);
			addBehaviour(clockBehaviour);
			
			MessageTemplate mt = SubscriptionResponder.createMessageTemplate(ACLMessage.SUBSCRIBE);
			addBehaviour(new SubscriptionResponder(this, mt, clockBehaviour));

			// Registrar servicio de medición del tiempo en el DF
			DFAgentDescription dfd = new DFAgentDescription();
			dfd.setName(getAID());
			ServiceDescription sd = new ServiceDescription();
			sd.setType("simulated-time");
			sd.setName("Lonja-Simulated-Time");
			dfd.addServices(sd);
			try {
				DFService.register(this, dfd);
			} catch(FIPAException fe) {
				fe.printStackTrace();
			}
		} else {
			System.out.println("Son necesarios 3 argumentos (<unitTimeMillis>,<numUnitDay>,<numSimDays>)");
			doDelete();
		}
	}
	
	@Override
	protected void takeDown() {
		try {
			DFService.deregister(this);
		} catch(FIPAException fe) {
			fe.printStackTrace();
		}
		super.takeDown();
	}
	
	/**
	 * Comportamiento que simula el paso del tiempo y notifica a los agentes que se hayan subscrito
	 * 
	 * @author pablo
	 *
	 */
	private class ClockTickerBehaviour extends TickerBehaviour implements SubscriptionManager {
		private Logger logger;
		// Número de milisegundos que forman una unidad de tiempo
		private int unitTimeMillis;
		// Número de unidades que forman un día
		private int numUnitDay;
		// Número de días que durará la simulación
		private int numSimDays;
		
		private int time = 0; // contador de unidades de tiempo
		private int day = 0; // contador de días
		
		List<Subscription> subs = new ArrayList<Subscription>();
		
		public ClockTickerBehaviour(Agent agent, int unitTimeMillis, int numUnitDay, int numSimDays) {
			super(agent, unitTimeMillis);
			this.unitTimeMillis = unitTimeMillis;
			this.numUnitDay = numUnitDay;
			this.numSimDays = numSimDays;
			
			this.logger = Logger.getMyLogger(getClass().getCanonicalName());
		}
		
		@Override
		protected void onTick() {
			time += 1;
			if (numUnitDay <= time) {
				// Otro día
				time = 0;
				day += 1;
			}
			
			if(day >= numSimDays) {
				// Notificar fin simulación
				this.logger.info(myAgent.getLocalName()+": Fin simulación!");
				// Mandar notificaciones de fin de la simulación
				notifySubsciptors(true);
				getAgent().doDelete();
			} else {
				// notificar agentes subscritos día y unidad de tiempo
				this.logger.info(myAgent.getLocalName()+": day="+day+", time="+time);
				// TODO Actualizar GUI del reloj vitual?
				notifySubsciptors(false);
			}
		}
		
		private void notifySubsciptors(boolean end) {
			ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
			SimTimeOntology obj = new SimTimeOntology(day, time);
			if(end) {
				obj.setSimState(SimTimeOntology.END);
			}
			String content = OntologyFactory.getSimTimeOntologyJSON(obj);
			System.out.println("json: "+content);
			// msg.setContent(content.getJSON());
			for(Subscription subscription: subs) {
				subscription.notify(msg);
			}
		}

		@Override
		public boolean deregister(Subscription subscription) throws FailureException {
			synchronized (subs) {
				this.logger.info(myAgent.getName()+": deregister("+subscription.getMessage().getSender().getName()+")");
				subs.remove(subscription);
			}
			return true;
		}

		@Override
		public boolean register(Subscription subscription) throws RefuseException, NotUnderstoodException {
			synchronized (subs) {
				this.logger.info(myAgent.getName()+": register("+subscription.getMessage().getSender().getName()+")");
				subs.add(subscription);
			}
			return true;
		}
	}
}
