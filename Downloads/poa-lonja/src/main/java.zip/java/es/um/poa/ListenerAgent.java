package es.um.poa;

import jade.util.Logger;

import java.io.Serializable;

import es.um.poa.ontologies.SimTimeOntology;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPANames;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.lang.acl.UnreadableException;
import jade.proto.SubscriptionInitiator;

public class ListenerAgent extends jade.core.Agent {
	private Logger logger;
	private AID clockAgent;
	
	public void setup() {
		this.logger = Logger.getMyLogger(getLocalName());
		
		DFAgentDescription template = new DFAgentDescription();// fill the template
		ServiceDescription sd = new ServiceDescription();
		sd.setType("simulated-time");
		template.addServices(sd);
		Behaviour b = new SubscriptionInitiator(
				this, DFService.createSubscriptionMessage(this, getDefaultDF(), template, null)) {
			protected void handleInform(ACLMessage inform) {
				try {
					DFAgentDescription[] dfds = DFService.decodeNotification(inform.getContent());
					if(dfds.length > 0) {
						clockAgent = dfds[0].getName();
						ACLMessage request = new ACLMessage(ACLMessage.SUBSCRIBE);
						request.setProtocol(FIPANames.InteractionProtocol.FIPA_SUBSCRIBE);
						request.setReplyWith(""+System.currentTimeMillis());
						request.addReceiver(clockAgent);
						myAgent.addBehaviour(new TimeUpdater(myAgent, request));
					}
				} catch (FIPAException fe) {
					fe.printStackTrace();
				}
			}
		};
		addBehaviour(b);
	}
	
	private class TimeUpdater extends SubscriptionInitiator {

		public TimeUpdater(Agent a, ACLMessage msg) {
			super(a, msg);
		}

		@Override
		protected void handleInform(ACLMessage inform) {
			try {
				SimTimeOntology sto = (SimTimeOntology) inform.getContentObject();
				System.out.println(sto.getDay()+","+sto.getTime());
			} catch (UnreadableException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
